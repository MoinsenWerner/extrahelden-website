# Extrahelden x WM (Flask)

## Start

```bash
cd /root/extrahelden_wm
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

App läuft auf: `http://0.0.0.0:2026`

## Enthalten

- Login/Registrierung (SHA-256 Passwort-Hash)
- Rollen: User/Admin
- Mannschaftsauswahl + Trikot-Customizing
- Warenkorb inkl. Bearbeiten/Löschen
- Checkout inkl. Creator-Code und Bestellanlage
- Profil + Bestellübersicht
- Support-Tickets + Ticket-Chat
- Admin Panel: Codes, Nutzer, Bestellungen, Tickets, Settings
- SQLite-DB unter `instance/database.sqlite`
