import base64
import hashlib
import os
import random
import re
import sqlite3
import string
from datetime import datetime, timedelta
from functools import wraps

import requests
import stripe
from flask import Flask, flash, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.utils import secure_filename

APP_HOST = "0.0.0.0"
APP_PORT = 2026
BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, "instance", "database.sqlite")

TEAM_OPTIONS = {
    "DE": "Deutschland",
    "AR": "Argentinien",
    "BR": "Brasilien",
    "FR": "Frankreich",
    "ESP": "Spanien",
    "AT": "Österreich",
    "CH": "Schweiz",
    "RO": "Rumänien",
    "IT": "Italien",
    "PT": "Portugal",
    "DK": "Dänemark",
    "BEL": "Belgien",
}

ALLOWED_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}
PLACEHOLDER_FRONT = "assets/trikots/placeholder-front.svg"
PLACEHOLDER_BACK = "assets/trikots/placeholder-back.svg"

ALLOWED_SIZES = ["XS", "S", "M", "L", "XL", "2XL", "3XL", "4XL", "5XL"]
PAYMENT_METHODS = ["Karte", "PayPal", "Überweisung"]

STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_PUBLISHABLE_KEY = os.getenv("STRIPE_PUBLISHABLE_KEY", "")
if STRIPE_SECRET_KEY:
    stripe.api_key = STRIPE_SECRET_KEY

PAYPAL_CLIENT_ID = os.getenv("PAYPAL_CLIENT_ID", "")
PAYPAL_CLIENT_SECRET = os.getenv("PAYPAL_CLIENT_SECRET", "")
PAYPAL_MODE = os.getenv("PAYPAL_MODE", "sandbox").lower()
PAYPAL_BASE_URL = "https://api-m.sandbox.paypal.com" if PAYPAL_MODE == "sandbox" else "https://api-m.paypal.com"

app = Flask(__name__)
app.secret_key = "extrahelden-secret-key-change-me"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def execute(query, params=(), fetchone=False, fetchall=False, commit=False):
    db = get_db()
    cur = db.execute(query, params)
    if commit:
        db.commit()
    if fetchone:
        return cur.fetchone()
    if fetchall:
        return cur.fetchall()
    return cur


def b64_encode(val):
    return base64.urlsafe_b64encode(str(val).encode()).decode()


def b64_decode(val):
    try:
        return int(base64.urlsafe_b64decode(val.encode()).decode())
    except Exception:
        return None


def hash_pw(value):
    return hashlib.sha256(value.encode()).hexdigest()


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Bitte zuerst einloggen.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)

    return wrapper


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        user = current_user()
        if not user or user["is_admin"] != 1:
            flash("Admin-Rechte erforderlich.", "danger")
            return redirect(url_for("index"))
        return fn(*args, **kwargs)

    return wrapper


def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return execute("SELECT * FROM users WHERE id=?", (uid,), fetchone=True)


def cart_count(uid):
    row = execute(
        "SELECT COUNT(*) c FROM shopping_cart WHERE user_id=? AND checkout_state=0",
        (uid,),
        fetchone=True,
    )
    return row["c"] if row else 0


def read_config_line(filename):
    path = os.path.join(BASE_DIR, "config", filename)
    if not os.path.exists(path):
        return ""
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()


def get_teams_rows():
    return execute(
        "SELECT code, name, front_image, back_image FROM teams WHERE is_active=1 ORDER BY name ASC",
        fetchall=True,
    )


def get_team_dict():
    rows = get_teams_rows()
    return {row["code"]: row["name"] for row in rows}


def get_team_by_code(code):
    return execute(
        "SELECT code, name, front_image, back_image FROM teams WHERE code=? AND is_active=1",
        (code,),
        fetchone=True,
    )


def allowed_image(filename):
    _, ext = os.path.splitext(filename.lower())
    return ext in ALLOWED_IMAGE_EXTENSIONS


def ensure_preview_placeholders():
    target_dir = os.path.join(BASE_DIR, "static", "assets", "trikots")
    os.makedirs(target_dir, exist_ok=True)
    front_path = os.path.join(target_dir, "placeholder-front.svg")
    back_path = os.path.join(target_dir, "placeholder-back.svg")
    if not os.path.exists(front_path):
        with open(front_path, "w", encoding="utf-8") as f:
            f.write(
                """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 760">
<rect width="640" height="760" fill="#eef5ff"/>
<rect x="64" y="50" width="512" height="660" rx="36" fill="#dce9fb" stroke="#aac7ed" stroke-width="6"/>
<text x="320" y="330" text-anchor="middle" font-family="Arial,sans-serif" font-size="34" fill="#335a87">TRIKOT VORNE</text>
<text x="320" y="380" text-anchor="middle" font-family="Arial,sans-serif" font-size="22" fill="#4c6f98">Bild folgt nach Upload</text>
</svg>"""
            )
    if not os.path.exists(back_path):
        with open(back_path, "w", encoding="utf-8") as f:
            f.write(
                """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 760">
<rect width="640" height="760" fill="#eef5ff"/>
<rect x="64" y="50" width="512" height="660" rx="36" fill="#dce9fb" stroke="#aac7ed" stroke-width="6"/>
<text x="320" y="330" text-anchor="middle" font-family="Arial,sans-serif" font-size="34" fill="#335a87">TRIKOT HINTEN</text>
<text x="320" y="380" text-anchor="middle" font-family="Arial,sans-serif" font-size="22" fill="#4c6f98">Bild folgt nach Upload</text>
</svg>"""
            )


def save_team_image(file_obj, team_code, side):
    if not file_obj or not file_obj.filename:
        return None
    safe_name = secure_filename(file_obj.filename)
    if not safe_name or not allowed_image(safe_name):
        return None
    _, ext = os.path.splitext(safe_name.lower())
    rel = f"assets/trikots/{team_code.lower()}-{side}{ext}"
    abs_path = os.path.join(BASE_DIR, "static", rel)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    file_obj.save(abs_path)
    return rel


def ensure_column(db, table, column, col_def):
    rows = db.execute(f"PRAGMA table_info({table})").fetchall()
    names = [r[1] for r in rows]
    if column not in names:
        db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_def}")


def add_business_days(start_date, business_days):
    d = start_date
    added = 0
    while added < business_days:
        d += timedelta(days=1)
        if d.weekday() < 5:
            added += 1
    return d


def shipping_cost(street, house_number, postal_code, city):
    origin_city = read_config_line("adress.txt")
    base = 4.99
    if origin_city and origin_city.lower() == (city or "").lower():
        return base
    if postal_code and len(postal_code) >= 2 and postal_code[:2] in {"10", "11", "12", "13", "14", "15", "16", "17", "18", "19"}:
        return base + 1.5
    return base + 2.5


def next_order_id():
    while True:
        cand = random.randint(100000, 999999)
        exists = execute("SELECT 1 FROM orders WHERE order_id=?", (cand,), fetchone=True)
        if not exists:
            return cand


def random_reference(n=10):
    chars = string.ascii_uppercase + string.digits
    while True:
        ref = "".join(random.choice(chars) for _ in range(n))
        exists = execute("SELECT 1 FROM orders WHERE verwendungszweck=?", (ref,), fetchone=True)
        if not exists:
            return ref


def validate_name(name):
    return bool(re.fullmatch(r"[A-Za-zÄÖÜäöüß]{1,9}", name or ""))


def validate_username(name):
    return bool(re.fullmatch(r"[A-Za-z0-9_\-@#]+", name or ""))


def validate_realname(name):
    return bool(re.fullmatch(r"[A-Za-zÄÖÜäöüß]+", name or ""))


def validate_password(pw):
    if len(pw or "") < 6 or " " in pw:
        return False
    if not re.fullmatch(r"[A-Za-z0-9_\-@#&%+.,]+", pw):
        return False
    checks = [
        bool(re.search(r"[a-z]", pw)),
        bool(re.search(r"[A-Z]", pw)),
        bool(re.search(r"[0-9]", pw)),
        bool(re.search(r"[_\-@#&%+.,]", pw)),
    ]
    return sum(checks) >= 3


def validate_street(v):
    return bool(re.fullmatch(r"[A-Za-zÄÖÜäöüß0-9\-\.\s]{2,80}", v or ""))


def validate_house_number(v):
    return bool(re.fullmatch(r"[A-Za-z0-9\-\/]{1,10}", v or ""))


def validate_postal(v):
    return bool(re.fullmatch(r"[0-9]{4,10}", v or ""))


def validate_city(v):
    return bool(re.fullmatch(r"[A-Za-zÄÖÜäöüß\-\s]{2,60}", v or ""))


def validate_creator_code(raw_code):
    code = (raw_code or "").strip().upper().replace(" ", "_")
    if not code:
        return None, ""
    row = execute("SELECT * FROM codes WHERE code=?", (code,), fetchone=True)
    return row, code


def calculate_discount(subtotal, shipping, creator_row):
    if not creator_row:
        return 0.0
    base = subtotal + shipping
    if creator_row["einheit"] == "%":
        return round(base * (float(creator_row["wert"]) / 100.0), 2)
    return round(float(creator_row["wert"]), 2)


def get_trikot_previews(team_code):
    ensure_preview_placeholders()
    row = get_team_by_code(team_code)
    code = (team_code or "").lower()

    front_candidates = []
    back_candidates = []

    if row and row["front_image"]:
        front_candidates.append(row["front_image"])
    if row and row["back_image"]:
        back_candidates.append(row["back_image"])

    front_candidates.extend([f"assets/trikots/{code}-front.png", f"assets/trikots/{code}-front.jpg", f"assets/trikots/{code}-front.webp"])
    back_candidates.extend([f"assets/trikots/{code}-back.png", f"assets/trikots/{code}-back.jpg", f"assets/trikots/{code}-back.webp"])

    front_rel = PLACEHOLDER_FRONT
    for rel in front_candidates:
        if rel and os.path.exists(os.path.join(BASE_DIR, "static", rel)):
            front_rel = rel
            break

    back_rel = PLACEHOLDER_BACK
    for rel in back_candidates:
        if rel and os.path.exists(os.path.join(BASE_DIR, "static", rel)):
            back_rel = rel
            break

    if back_rel == PLACEHOLDER_BACK and front_rel != PLACEHOLDER_FRONT:
        back_rel = front_rel
    return front_rel, back_rel


def trikot_preview_abs_path(team_code, side):
    side_normalized = "front" if side == "front" else "back"
    front_rel, back_rel = get_trikot_previews(team_code)
    rel = front_rel if side_normalized == "front" else back_rel
    abs_path = os.path.join(BASE_DIR, "static", rel)
    if os.path.exists(abs_path):
        return abs_path
    fallback_rel = PLACEHOLDER_FRONT if side_normalized == "front" else PLACEHOLDER_BACK
    return os.path.join(BASE_DIR, "static", fallback_rel)


def paypal_get_token():
    if not PAYPAL_CLIENT_ID or not PAYPAL_CLIENT_SECRET:
        return None, "PayPal API nicht konfiguriert (PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET fehlen)."
    try:
        resp = requests.post(
            f"{PAYPAL_BASE_URL}/v1/oauth2/token",
            data={"grant_type": "client_credentials"},
            auth=(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET),
            timeout=20,
        )
        if resp.status_code >= 400:
            return None, f"PayPal Token-Fehler: {resp.status_code}"
        return resp.json().get("access_token"), None
    except Exception as exc:
        return None, f"PayPal Token-Fehler: {exc}"


def paypal_create_order(order_id, total_amount, reference):
    token, err = paypal_get_token()
    if err:
        return None, err
    success_url = url_for("payment_paypal_return", _external=True) + f"?order_id={order_id}"
    cancel_url = url_for("payment_paypal_cancel", _external=True) + f"?order_id={order_id}"
    payload = {
        "intent": "CAPTURE",
        "purchase_units": [
            {
                "reference_id": f"ORDER-{order_id}",
                "invoice_id": str(order_id),
                "custom_id": reference,
                "amount": {
                    "currency_code": "EUR",
                    "value": f"{total_amount:.2f}",
                },
            }
        ],
        "application_context": {
            "return_url": success_url,
            "cancel_url": cancel_url,
            "brand_name": "Extrahelden x WM",
            "landing_page": "LOGIN",
            "user_action": "PAY_NOW",
        },
    }
    try:
        resp = requests.post(
            f"{PAYPAL_BASE_URL}/v2/checkout/orders",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=25,
        )
        data = resp.json()
        if resp.status_code >= 400:
            return None, f"PayPal Order-Fehler: {resp.status_code}"
        approve_url = None
        for link in data.get("links", []):
            if link.get("rel") == "approve":
                approve_url = link.get("href")
                break
        if not approve_url:
            return None, "PayPal Approve-Link fehlt."
        return {
            "paypal_order_id": data.get("id"),
            "approve_url": approve_url,
            "status": data.get("status"),
        }, None
    except Exception as exc:
        return None, f"PayPal Order-Fehler: {exc}"


def paypal_capture_order(paypal_order_id):
    token, err = paypal_get_token()
    if err:
        return None, err
    try:
        resp = requests.post(
            f"{PAYPAL_BASE_URL}/v2/checkout/orders/{paypal_order_id}/capture",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json={},
            timeout=25,
        )
        data = resp.json()
        if resp.status_code >= 400:
            return None, f"PayPal Capture-Fehler: {resp.status_code}"
        return data, None
    except Exception as exc:
        return None, f"PayPal Capture-Fehler: {exc}"


def paypal_get_order(paypal_order_id):
    token, err = paypal_get_token()
    if err:
        return None, err
    try:
        resp = requests.get(
            f"{PAYPAL_BASE_URL}/v2/checkout/orders/{paypal_order_id}",
            headers={"Authorization": f"Bearer {token}"},
            timeout=20,
        )
        data = resp.json()
        if resp.status_code >= 400:
            return None, f"PayPal Status-Fehler: {resp.status_code}"
        return data, None
    except Exception as exc:
        return None, f"PayPal Status-Fehler: {exc}"


def parse_paypal_paid(order_data):
    if not order_data:
        return False, "unbekannt"
    status = order_data.get("status", "")
    if status == "COMPLETED":
        return True, status
    for pu in order_data.get("purchase_units", []):
        captures = (pu.get("payments") or {}).get("captures") or []
        for cap in captures:
            if cap.get("status") == "COMPLETED":
                return True, "CAPTURE_COMPLETED"
    return False, status or "unbekannt"


def update_order_payment_state(order_id, paid, provider_state):
    if paid:
        execute(
            "UPDATE orders SET payment_progress='bezahlt', payment_date=?, payment_provider_status=? WHERE order_id=?",
            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), provider_state, order_id),
            commit=True,
        )
    else:
        execute(
            "UPDATE orders SET payment_provider_status=? WHERE order_id=?",
            (provider_state, order_id),
            commit=True,
        )


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            name TEXT NOT NULL,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS shopping_cart (
            shopping_cart_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            selected_number TEXT NOT NULL,
            size TEXT NOT NULL,
            amount INTEGER NOT NULL,
            team TEXT NOT NULL,
            prize REAL NOT NULL,
            checkout_state INTEGER NOT NULL DEFAULT 0,
            creator_code TEXT
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS tickets (
            ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            titel TEXT NOT NULL,
            description TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'offen',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS ticket_messages (
            message_id INTEGER PRIMARY KEY AUTOINCREMENT,
            sende_by INTEGER NOT NULL,
            timestamp TEXT NOT NULL,
            message_content TEXT NOT NULL,
            ticket_id INTEGER NOT NULL
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS codes (
            code TEXT PRIMARY KEY,
            wert REAL NOT NULL,
            einheit TEXT NOT NULL,
            usage INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS settings (
            setting_key TEXT PRIMARY KEY,
            setting_value TEXT NOT NULL
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS teams (
            code TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            front_image TEXT,
            back_image TEXT,
            is_active INTEGER NOT NULL DEFAULT 1
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS orders (
            order_id INTEGER PRIMARY KEY,
            payment_progress TEXT NOT NULL,
            verwendungszweck TEXT UNIQUE NOT NULL,
            user_id INTEGER NOT NULL,
            prize REAL NOT NULL,
            cart_ids TEXT NOT NULL,
            adress TEXT NOT NULL,
            order_date TEXT NOT NULL,
            payment_due_date TEXT NOT NULL,
            payment_date TEXT,
            bearbeitungsstatus TEXT NOT NULL DEFAULT 'ausstehend',
            payment_method TEXT NOT NULL,
            storniert INTEGER NOT NULL DEFAULT 0,
            creator_code TEXT,
            shipping_cost REAL NOT NULL DEFAULT 0,
            creator_discount REAL NOT NULL DEFAULT 0,
            street TEXT,
            house_number TEXT,
            postal_code TEXT,
            city TEXT,
            recipient_first_name TEXT,
            recipient_last_name TEXT,
            stripe_session_id TEXT,
            paypal_order_id TEXT,
            provider_reference TEXT,
            payment_provider_status TEXT
        )
        """
    )

    ensure_column(db, "orders", "shipping_cost", "REAL NOT NULL DEFAULT 0")
    ensure_column(db, "orders", "creator_discount", "REAL NOT NULL DEFAULT 0")
    ensure_column(db, "orders", "street", "TEXT")
    ensure_column(db, "orders", "house_number", "TEXT")
    ensure_column(db, "orders", "postal_code", "TEXT")
    ensure_column(db, "orders", "city", "TEXT")
    ensure_column(db, "orders", "recipient_first_name", "TEXT")
    ensure_column(db, "orders", "recipient_last_name", "TEXT")
    ensure_column(db, "orders", "stripe_session_id", "TEXT")
    ensure_column(db, "orders", "paypal_order_id", "TEXT")
    ensure_column(db, "orders", "provider_reference", "TEXT")
    ensure_column(db, "orders", "payment_provider_status", "TEXT")
    ensure_column(db, "teams", "front_image", "TEXT")
    ensure_column(db, "teams", "back_image", "TEXT")
    ensure_column(db, "teams", "is_active", "INTEGER NOT NULL DEFAULT 1")

    ensure_preview_placeholders()
    for code, name in TEAM_OPTIONS.items():
        front_rel = f"assets/trikots/{code.lower()}-front.png"
        back_rel = f"assets/trikots/{code.lower()}-back.png"
        db.execute(
            """
            INSERT OR IGNORE INTO teams (code, name, front_image, back_image, is_active)
            VALUES (?, ?, ?, ?, 1)
            """,
            (code, name, front_rel, back_rel),
        )
        db.execute(
            """
            UPDATE teams
            SET name=?,
                front_image=CASE WHEN front_image IS NULL OR front_image='' THEN ? ELSE front_image END,
                back_image=CASE WHEN back_image IS NULL OR back_image='' THEN ? ELSE back_image END,
                is_active=1
            WHERE code=?
            """,
            (name, front_rel, back_rel, code),
        )

    team_rows = db.execute("SELECT code FROM teams WHERE is_active=1").fetchall()
    for row in team_rows:
        db.execute(
            "INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES (?, ?)",
            (row[0], "89.90"),
        )
    db.execute(
        "INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES ('frist', '2026-12-31')"
    )
    admin = db.execute("SELECT id FROM users WHERE username='admin'", ()).fetchone()
    if not admin:
        db.execute(
            "INSERT INTO users (first_name, name, username, email, password, is_admin) VALUES (?,?,?,?,?,1)",
            ("Admin", "User", "admin", "admin@example.com", hash_pw("Admin#2026")),
        )
    db.commit()
    db.close()


@app.context_processor
def inject_global():
    user = current_user()
    teams = get_team_dict()
    if not teams:
        teams = TEAM_OPTIONS
    return {
        "current_user": user,
        "cart_open_count": cart_count(user["id"]) if user else 0,
        "teams": teams,
        "b64_encode": b64_encode,
    }


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        pw = request.form.get("password", "")
        row = execute(
            "SELECT * FROM users WHERE (username=? OR email=?) AND password=?",
            (identifier, identifier, hash_pw(pw)),
            fetchone=True,
        )
        if row:
            session["user_id"] = row["id"]
            flash("Erfolgreich eingeloggt.", "success")
            return redirect(url_for("index"))
        flash("Login fehlgeschlagen.", "danger")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        first_name = request.form.get("first_name", "").strip()
        name = request.form.get("name", "").strip()
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        if not validate_realname(first_name) or not validate_realname(name):
            flash("Vorname/Nachname ungültig.", "danger")
        elif not validate_username(username):
            flash("Username ungültig.", "danger")
        elif not validate_password(password):
            flash("Passwort erfüllt Anforderungen nicht.", "danger")
        else:
            try:
                execute(
                    "INSERT INTO users (first_name, name, username, email, password, is_admin) VALUES (?,?,?,?,?,0)",
                    (first_name, name, username, email, hash_pw(password)),
                    commit=True,
                )
                flash("Account erstellt. Bitte einloggen.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username oder E-Mail bereits vergeben.", "warning")
    return render_template("register.html")


@app.route("/logout")
@login_required
def logout():
    session.clear()
    flash("Ausgeloggt.", "info")
    return redirect(url_for("index"))


@app.route("/customizing", methods=["GET", "POST"])
@login_required
def customizing():
    user = current_user()
    teams_map = get_team_dict()
    if not teams_map:
        teams_map = TEAM_OPTIONS
    team = request.args.get("team", "DE").upper()
    if team not in teams_map:
        team = next(iter(teams_map.keys()))

    edit_id = request.args.get("shoppingcardid", "")
    editing = None
    if edit_id.isdigit():
        editing = execute(
            "SELECT * FROM shopping_cart WHERE shopping_cart_id=? AND user_id=?",
            (int(edit_id), user["id"]),
            fetchone=True,
        )
        if editing:
            team = editing["team"]

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        number = request.form.get("selected_number", "").strip()
        size = request.form.get("size", "M")
        amount = int(request.form.get("amount", "1") or 1)
        team = request.form.get("team", team).upper()
        if team not in teams_map:
            team = next(iter(teams_map.keys()))

        if not validate_name(name):
            flash("Name ungültig (nur Buchstaben, max 9).", "danger")
        elif not number.isdigit() or not (1 <= int(number) <= 99):
            flash("Nummer muss 1-99 sein.", "danger")
        elif size not in ALLOWED_SIZES:
            flash("Größe ungültig.", "danger")
        else:
            if amount < 1:
                amount = 1
            num = f"{int(number):02d}"
            price_row = execute("SELECT setting_value FROM settings WHERE setting_key=?", (team,), fetchone=True)
            if not price_row:
                execute(
                    "INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES (?,?)",
                    (team, "89.90"),
                    commit=True,
                )
                base_price = 89.9
            else:
                base_price = float(price_row["setting_value"])
            total = round(base_price * amount, 2)
            if editing:
                execute(
                    "UPDATE shopping_cart SET name=?, selected_number=?, size=?, amount=?, team=?, prize=? WHERE shopping_cart_id=? AND user_id=?",
                    (name, num, size, amount, team, total, editing["shopping_cart_id"], user["id"]),
                    commit=True,
                )
                flash("Warenkorbeintrag aktualisiert.", "success")
                return redirect(url_for("shoppingcart"))
            execute(
                "INSERT INTO shopping_cart (user_id, name, selected_number, size, amount, team, prize, checkout_state) VALUES (?,?,?,?,?,?,?,0)",
                (user["id"], name, num, size, amount, team, total),
                commit=True,
            )
            flash("Zum Warenkorb hinzugefügt.", "success")
            return redirect(url_for("shoppingcart"))

    front_preview, back_preview = get_trikot_previews(team)
    return render_template(
        "customizing.html",
        team=team,
        editing=editing,
        front_preview=front_preview,
        back_preview=back_preview,
    )


@app.route("/shoppingcart", methods=["GET", "POST"])
@login_required
def shoppingcart():
    user = current_user()
    if request.method == "POST":
        action = request.form.get("action")
        cart_id = int(request.form.get("cart_id", "0") or 0)
        if action == "delete":
            execute(
                "DELETE FROM shopping_cart WHERE shopping_cart_id=? AND user_id=? AND checkout_state=0",
                (cart_id, user["id"]),
                commit=True,
            )
            flash("Eintrag gelöscht.", "info")
    rows = execute(
        "SELECT * FROM shopping_cart WHERE user_id=? AND checkout_state=0 ORDER BY shopping_cart_id DESC",
        (user["id"],),
        fetchall=True,
    )
    return render_template("shoppingcart.html", rows=rows)


@app.route("/trikotbild/<team_code>/<side>")
def team_trikot_image(team_code, side):
    team = (team_code or "").upper()
    side_normalized = (side or "").lower()
    if not re.fullmatch(r"[A-Z]{2,5}", team):
        team = "DE"
    if side_normalized not in {"front", "back"}:
        side_normalized = "front"

    img_path = trikot_preview_abs_path(team, side_normalized)
    mime = "image/png"
    if img_path.endswith(".jpg") or img_path.endswith(".jpeg"):
        mime = "image/jpeg"
    elif img_path.endswith(".webp"):
        mime = "image/webp"
    elif img_path.endswith(".svg"):
        mime = "image/svg+xml"

    with open(img_path, "rb") as f:
        data = f.read()
    return app.response_class(data, mimetype=mime)


@app.route("/api/shipping_quote", methods=["POST"])
@login_required
def api_shipping_quote():
    street = request.form.get("street", "").strip()
    house_number = request.form.get("house_number", "").strip()
    postal_code = request.form.get("postal_code", "").strip()
    city = request.form.get("city", "").strip()

    if not (validate_street(street) and validate_house_number(house_number) and validate_postal(postal_code) and validate_city(city)):
        return jsonify({"ok": False, "error": "Adresse unvollständig oder ungültig."}), 400

    shipping = shipping_cost(street, house_number, postal_code, city)
    return jsonify({"ok": True, "shipping": round(shipping, 2)})


@app.route("/api/creator_code_check", methods=["POST"])
@login_required
def api_creator_code_check():
    code_raw = request.form.get("creator_code", "")
    try:
        subtotal = float(request.form.get("subtotal", "0") or 0)
        shipping = float(request.form.get("shipping", "0") or 0)
    except ValueError:
        return jsonify({"ok": False, "error": "Ungültige Preisparameter."}), 400

    row, normalized_code = validate_creator_code(code_raw)
    if not normalized_code:
        return jsonify({"ok": True, "exists": False, "discount": 0.0, "total": round(subtotal + shipping, 2)})
    if not row:
        return jsonify({"ok": True, "exists": False, "code": normalized_code, "discount": 0.0, "total": round(subtotal + shipping, 2)})

    discount = calculate_discount(subtotal, shipping, row)
    total = max(0.0, round(subtotal + shipping - discount, 2))
    return jsonify(
        {
            "ok": True,
            "exists": True,
            "code": normalized_code,
            "discount": round(discount, 2),
            "unit": row["einheit"],
            "value": float(row["wert"]),
            "total": total,
        }
    )


@app.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    user_param = request.args.get("user", "")
    uid = b64_decode(user_param) if user_param else session.get("user_id")
    if uid != session.get("user_id"):
        flash("Ungültiger Nutzerparameter.", "danger")
        return redirect(url_for("shoppingcart"))

    user = current_user()
    cart_rows = execute(
        "SELECT * FROM shopping_cart WHERE user_id=? AND checkout_state=0",
        (user["id"],),
        fetchall=True,
    )
    if not cart_rows:
        flash("Warenkorb ist leer.", "warning")
        return redirect(url_for("shoppingcart"))

    subtotal = round(sum(r["prize"] for r in cart_rows), 2)
    show_modal = False
    modal = None

    form_values = {
        "street": "",
        "house_number": "",
        "postal_code": "",
        "city": "",
        "first_name": user["first_name"],
        "last_name": user["name"],
        "creator_code": "",
        "payment_method": "Karte",
    }

    shipping = 0.0
    discount = 0.0
    total = subtotal

    if request.method == "POST":
        action = request.form.get("action", "prepare")
        form_values = {
            "street": request.form.get("street", "").strip(),
            "house_number": request.form.get("house_number", "").strip(),
            "postal_code": request.form.get("postal_code", "").strip(),
            "city": request.form.get("city", "").strip(),
            "first_name": request.form.get("first_name", user["first_name"]).strip() or user["first_name"],
            "last_name": request.form.get("last_name", user["name"]).strip() or user["name"],
            "creator_code": request.form.get("creator_code", "").strip(),
            "payment_method": request.form.get("payment_method", "Karte"),
        }

        if form_values["payment_method"] not in PAYMENT_METHODS:
            flash("Bezahlmethode ungültig.", "danger")
            return render_template(
                "checkout.html",
                cart_rows=cart_rows,
                subtotal=subtotal,
                shipping=shipping,
                discount=discount,
                total=total,
                form_values=form_values,
                stripe_publishable_key=STRIPE_PUBLISHABLE_KEY,
                paypal_email=read_config_line("paypal.txt"),
            )

        if not validate_street(form_values["street"]):
            flash("Straße ungültig.", "danger")
        elif not validate_house_number(form_values["house_number"]):
            flash("Hausnummer ungültig.", "danger")
        elif not validate_postal(form_values["postal_code"]):
            flash("Postleitzahl ungültig.", "danger")
        elif not validate_city(form_values["city"]):
            flash("Ort ungültig.", "danger")
        elif not validate_realname(form_values["first_name"]) or not validate_realname(form_values["last_name"]):
            flash("Vorname/Nachname ungültig.", "danger")
        else:
            shipping = shipping_cost(
                form_values["street"],
                form_values["house_number"],
                form_values["postal_code"],
                form_values["city"],
            )

            creator_row, normalized_code = validate_creator_code(form_values["creator_code"])
            if normalized_code and not creator_row:
                flash("Creator-Code nicht gefunden.", "warning")
                form_values["creator_code"] = ""
            else:
                form_values["creator_code"] = normalized_code

            discount = calculate_discount(subtotal, shipping, creator_row)
            total = max(0.0, round(subtotal + shipping - discount, 2))

            if action == "prepare":
                due = add_business_days(datetime.now(), 5)
                show_modal = True
                modal_reference = random_reference(10)
                modal = {
                    "reference": modal_reference,
                    "final_total": f"{total:.2f}",
                    "shipping": f"{shipping:.2f}",
                    "discount": f"{discount:.2f}",
                    "due_date": due.strftime("%d.%m.%Y %H:%M"),
                }
            elif action == "place":
                order_id = next_order_id()
                reference = request.form.get("prepared_reference", "").strip().upper()
                if not re.fullmatch(r"[A-Z0-9]{10}", reference or ""):
                    reference = random_reference(10)
                exists_ref = execute("SELECT 1 FROM orders WHERE verwendungszweck=?", (reference,), fetchone=True)
                if exists_ref:
                    reference = random_reference(10)
                now = datetime.now()
                due = add_business_days(now, 5)
                open_ids = [str(r["shopping_cart_id"]) for r in cart_rows]
                address_line = (
                    f"{form_values['street']}, {form_values['house_number']}, {form_values['postal_code']}, "
                    f"{form_values['city']}, {form_values['first_name']}, {form_values['last_name']}"
                )

                execute(
                    """
                    INSERT INTO orders (
                      order_id, payment_progress, verwendungszweck, user_id, prize, cart_ids, adress,
                      order_date, payment_due_date, payment_date, bearbeitungsstatus, payment_method,
                      storniert, creator_code, shipping_cost, creator_discount, street, house_number,
                      postal_code, city, recipient_first_name, recipient_last_name, provider_reference
                    )
                    VALUES (?, 'ausstehend', ?, ?, ?, ?, ?, ?, ?, NULL, 'ausstehend', ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        order_id,
                        reference,
                        user["id"],
                        total,
                        ",".join(open_ids),
                        address_line,
                        now.strftime("%Y-%m-%d %H:%M:%S"),
                        due.strftime("%Y-%m-%d %H:%M:%S"),
                        form_values["payment_method"],
                        form_values["creator_code"] or None,
                        shipping,
                        discount,
                        form_values["street"],
                        form_values["house_number"],
                        form_values["postal_code"],
                        form_values["city"],
                        form_values["first_name"],
                        form_values["last_name"],
                        reference,
                    ),
                    commit=True,
                )

                execute(
                    f"UPDATE shopping_cart SET checkout_state=1, creator_code=? WHERE shopping_cart_id IN ({','.join('?'*len(open_ids))})",
                    tuple([form_values["creator_code"] or None] + [int(x) for x in open_ids]),
                    commit=True,
                )

                if form_values["creator_code"]:
                    execute("UPDATE codes SET usage = usage + 1 WHERE code=?", (form_values["creator_code"],), commit=True)

                if form_values["payment_method"] == "Karte":
                    if not STRIPE_SECRET_KEY:
                        flash("Stripe ist nicht konfiguriert. Setze STRIPE_SECRET_KEY in der Umgebung.", "danger")
                        return redirect(url_for("userorderdetails", orderid=order_id))
                    try:
                        success_url = (
                            url_for("payment_stripe_success", _external=True)
                            + f"?order_id={order_id}&session_id={{CHECKOUT_SESSION_ID}}"
                        )
                        cancel_url = url_for("payment_stripe_cancel", _external=True) + f"?order_id={order_id}"
                        stripe_session = stripe.checkout.Session.create(
                            mode="payment",
                            line_items=[
                                {
                                    "price_data": {
                                        "currency": "eur",
                                        "product_data": {"name": f"Extrahelden WM Bestellung #{order_id}"},
                                        "unit_amount": int(round(total * 100)),
                                    },
                                    "quantity": 1,
                                }
                            ],
                            success_url=success_url,
                            cancel_url=cancel_url,
                            client_reference_id=str(order_id),
                            metadata={"order_id": str(order_id), "reference": reference},
                        )
                        execute(
                            "UPDATE orders SET stripe_session_id=?, payment_provider_status=? WHERE order_id=?",
                            (stripe_session.id, "created", order_id),
                            commit=True,
                        )
                        return redirect(stripe_session.url)
                    except Exception as exc:
                        execute(
                            "UPDATE orders SET payment_provider_status=? WHERE order_id=?",
                            (f"stripe_error:{exc}", order_id),
                            commit=True,
                        )
                        flash(f"Stripe Fehler: {exc}", "danger")
                        return redirect(url_for("userorderdetails", orderid=order_id))

                if form_values["payment_method"] == "PayPal":
                    pp_data, pp_err = paypal_create_order(order_id, total, reference)
                    if pp_err:
                        execute(
                            "UPDATE orders SET payment_provider_status=? WHERE order_id=?",
                            (f"paypal_error:{pp_err}", order_id),
                            commit=True,
                        )
                        flash(pp_err, "danger")
                        return redirect(url_for("userorderdetails", orderid=order_id))
                    execute(
                        "UPDATE orders SET paypal_order_id=?, payment_provider_status=? WHERE order_id=?",
                        (pp_data["paypal_order_id"], pp_data.get("status", "created"), order_id),
                        commit=True,
                    )
                    return redirect(pp_data["approve_url"])

                flash(
                    f"Vorbestellung erstellt. Verwendungszweck: {reference} | Endpreis: {total:.2f} € | "
                    f"Fällig bis: {due.strftime('%d.%m.%Y %H:%M')}",
                    "success",
                )
                return redirect(url_for("index"))

    return render_template(
        "checkout.html",
        cart_rows=cart_rows,
        subtotal=subtotal,
        shipping=round(shipping, 2),
        discount=round(discount, 2),
        total=round(total, 2),
        form_values=form_values,
        show_modal=show_modal,
        modal=modal,
        stripe_publishable_key=STRIPE_PUBLISHABLE_KEY,
        paypal_email=read_config_line("paypal.txt"),
    )


@app.route("/payment/stripe/success")
@login_required
def payment_stripe_success():
    order_id = request.args.get("order_id", "")
    session_id = request.args.get("session_id", "")
    if not order_id.isdigit() or not session_id:
        flash("Ungültige Stripe-Rückleitung.", "danger")
        return redirect(url_for("profile"))

    order = execute(
        "SELECT * FROM orders WHERE order_id=? AND user_id=?",
        (int(order_id), session.get("user_id")),
        fetchone=True,
    )
    if not order:
        flash("Bestellung nicht gefunden.", "danger")
        return redirect(url_for("profile"))

    if not STRIPE_SECRET_KEY:
        flash("Stripe nicht konfiguriert.", "danger")
        return redirect(url_for("userorderdetails", orderid=order_id))

    try:
        sess = stripe.checkout.Session.retrieve(session_id)
        paid = sess.get("payment_status") == "paid"
        state = sess.get("payment_status", "unknown")
        update_order_payment_state(int(order_id), paid, f"stripe:{state}")
        if paid:
            flash("Stripe-Zahlung bestätigt.", "success")
        else:
            flash("Stripe-Zahlung noch ausstehend.", "warning")
    except Exception as exc:
        flash(f"Stripe-Status konnte nicht geprüft werden: {exc}", "danger")
    return redirect(url_for("userorderdetails", orderid=order_id))


@app.route("/payment/stripe/cancel")
@login_required
def payment_stripe_cancel():
    order_id = request.args.get("order_id", "")
    if order_id.isdigit():
        execute(
            "UPDATE orders SET payment_provider_status=? WHERE order_id=? AND user_id=?",
            ("stripe:cancelled", int(order_id), session.get("user_id")),
            commit=True,
        )
    flash("Stripe-Zahlung wurde abgebrochen.", "warning")
    return redirect(url_for("userorderdetails", orderid=order_id if order_id.isdigit() else ""))


@app.route("/payment/paypal/return")
@login_required
def payment_paypal_return():
    order_id = request.args.get("order_id", "")
    if not order_id.isdigit():
        flash("Ungültige PayPal-Rückleitung.", "danger")
        return redirect(url_for("profile"))
    order = execute(
        "SELECT * FROM orders WHERE order_id=? AND user_id=?",
        (int(order_id), session.get("user_id")),
        fetchone=True,
    )
    if not order:
        flash("Bestellung nicht gefunden.", "danger")
        return redirect(url_for("profile"))
    if not order["paypal_order_id"]:
        flash("Keine PayPal-Order hinterlegt.", "danger")
        return redirect(url_for("userorderdetails", orderid=order_id))

    capture_data, capture_err = paypal_capture_order(order["paypal_order_id"])
    if capture_err:
        flash(capture_err, "danger")
        return redirect(url_for("userorderdetails", orderid=order_id))

    paid, state = parse_paypal_paid(capture_data)
    update_order_payment_state(int(order_id), paid, f"paypal:{state}")
    if paid:
        flash("PayPal-Zahlung bestätigt.", "success")
    else:
        flash("PayPal-Zahlung noch nicht abgeschlossen.", "warning")
    return redirect(url_for("userorderdetails", orderid=order_id))


@app.route("/payment/paypal/cancel")
@login_required
def payment_paypal_cancel():
    order_id = request.args.get("order_id", "")
    if order_id.isdigit():
        execute(
            "UPDATE orders SET payment_provider_status=? WHERE order_id=? AND user_id=?",
            ("paypal:cancelled", int(order_id), session.get("user_id")),
            commit=True,
        )
    flash("PayPal-Zahlung wurde abgebrochen.", "warning")
    return redirect(url_for("userorderdetails", orderid=order_id if order_id.isdigit() else ""))


@app.route("/api/payment_status/<int:order_id>")
@login_required
def api_payment_status(order_id):
    user = current_user()
    order = execute("SELECT * FROM orders WHERE order_id=?", (order_id,), fetchone=True)
    if not order:
        return jsonify({"ok": False, "error": "Order nicht gefunden"}), 404
    if user["is_admin"] != 1 and order["user_id"] != user["id"]:
        return jsonify({"ok": False, "error": "Kein Zugriff"}), 403

    method = order["payment_method"]
    if method == "Karte" and order["stripe_session_id"] and STRIPE_SECRET_KEY:
        try:
            sess = stripe.checkout.Session.retrieve(order["stripe_session_id"])
            state = sess.get("payment_status", "unknown")
            paid = state == "paid"
            update_order_payment_state(order_id, paid, f"stripe:{state}")
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Stripe Fehler: {exc}"}), 500

    if method == "PayPal" and order["paypal_order_id"]:
        pp_data, pp_err = paypal_get_order(order["paypal_order_id"])
        if pp_err:
            return jsonify({"ok": False, "error": pp_err}), 500
        paid, state = parse_paypal_paid(pp_data)
        update_order_payment_state(order_id, paid, f"paypal:{state}")

    order = execute("SELECT * FROM orders WHERE order_id=?", (order_id,), fetchone=True)
    return jsonify(
        {
            "ok": True,
            "order_id": order["order_id"],
            "payment_progress": order["payment_progress"],
            "payment_method": order["payment_method"],
            "payment_provider_status": order["payment_provider_status"],
            "payment_date": order["payment_date"],
            "reference": order["verwendungszweck"],
        }
    )


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = current_user()
    if request.method == "POST":
        first_name = request.form.get("first_name", "").strip()
        name = request.form.get("name", "").strip()
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        if not validate_realname(first_name) or not validate_realname(name):
            flash("Vorname/Nachname ungültig.", "danger")
        elif not validate_username(username):
            flash("Username ungültig.", "danger")
        else:
            try:
                execute(
                    "UPDATE users SET first_name=?, name=?, username=?, email=? WHERE id=?",
                    (first_name, name, username, email, user["id"]),
                    commit=True,
                )
                flash("Profil aktualisiert.", "success")
            except sqlite3.IntegrityError:
                flash("Username oder E-Mail bereits vergeben.", "warning")
    user = current_user()
    orders = execute(
        "SELECT order_id, payment_progress, bearbeitungsstatus FROM orders WHERE user_id=? ORDER BY order_date DESC",
        (user["id"],),
        fetchall=True,
    )
    return render_template("profile.html", user=user, orders=orders)


@app.route("/userorderdetails")
@login_required
def userorderdetails():
    user = current_user()
    order_id = request.args.get("orderid", "")
    order = execute(
        "SELECT * FROM orders WHERE order_id=? AND user_id=?",
        (order_id, user["id"]),
        fetchone=True,
    )
    if not order:
        flash("Bestellung nicht gefunden.", "danger")
        return redirect(url_for("profile"))
    return render_template("userorderdetails.html", order=order)


@app.route("/cancel_order", methods=["POST"])
@login_required
def cancel_order():
    user = current_user()
    order_id = request.form.get("order_id")
    execute(
        "UPDATE orders SET storniert=1 WHERE order_id=? AND user_id=?",
        (order_id, user["id"]),
        commit=True,
    )
    flash("Bestellung storniert.", "info")
    return redirect(url_for("userorderdetails", orderid=order_id))


@app.route("/support", methods=["GET", "POST"])
@login_required
def support():
    user = current_user()
    if request.method == "POST":
        titel = request.form.get("titel", "").strip()
        desc = request.form.get("description", "").strip()
        if not titel or not desc:
            flash("Titel und Beschreibung sind erforderlich.", "danger")
        else:
            execute(
                "INSERT INTO tickets (user_id, titel, description, status) VALUES (?,?,?, 'offen')",
                (user["id"], titel, desc),
                commit=True,
            )
            flash("Ticket erstellt.", "success")
    if user["is_admin"]:
        tickets = execute(
            "SELECT t.*, u.username FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.status!='gelöscht' ORDER BY t.ticket_id DESC",
            fetchall=True,
        )
    else:
        tickets = execute(
            "SELECT t.*, u.username FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.user_id=? AND t.status!='gelöscht' ORDER BY t.ticket_id DESC",
            (user["id"],),
            fetchall=True,
        )
    return render_template("support.html", tickets=tickets)


@app.route("/ticket", methods=["GET", "POST"])
@login_required
def ticket():
    user = current_user()
    tid = request.args.get("ticketid", "")
    ticket_row = execute(
        "SELECT t.*, u.username FROM tickets t JOIN users u ON u.id=t.user_id WHERE ticket_id=?",
        (tid,),
        fetchone=True,
    )
    if not ticket_row:
        flash("Ticket nicht gefunden.", "danger")
        return redirect(url_for("support"))
    if user["is_admin"] != 1 and ticket_row["user_id"] != user["id"]:
        flash("Kein Zugriff auf dieses Ticket.", "danger")
        return redirect(url_for("support"))
    if request.method == "POST":
        action = request.form.get("action")
        if action == "message":
            msg = request.form.get("message_content", "").strip()
            if msg:
                execute(
                    "INSERT INTO ticket_messages (sende_by, timestamp, message_content, ticket_id) VALUES (?,?,?,?)",
                    (user["id"], datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg, tid),
                    commit=True,
                )
        elif action == "close":
            execute("UPDATE tickets SET status='geschlossen' WHERE ticket_id=?", (tid,), commit=True)
        elif action == "delete" and (user["is_admin"] == 1 or ticket_row["user_id"] == user["id"]):
            execute("UPDATE tickets SET status='gelöscht' WHERE ticket_id=?", (tid,), commit=True)
    msgs = execute(
        "SELECT m.*, u.username FROM ticket_messages m JOIN users u ON u.id=m.sende_by WHERE m.ticket_id=? ORDER BY m.message_id ASC",
        (tid,),
        fetchall=True,
    )
    ticket_row = execute(
        "SELECT t.*, u.username FROM tickets t JOIN users u ON u.id=t.user_id WHERE ticket_id=?",
        (tid,),
        fetchone=True,
    )
    return render_template("ticket.html", ticket=ticket_row, messages=msgs)


@app.route("/admin/creatorcodes", methods=["GET", "POST"])
@admin_required
def admin_creatorcodes():
    if request.method == "POST":
        code = request.form.get("code", "").strip().upper().replace(" ", "_")
        wert = request.form.get("wert", "").strip()
        einheit = request.form.get("einheit", "€")
        try:
            wert_f = float(wert)
        except ValueError:
            wert_f = None
        if not code or wert_f is None or einheit not in ["€", "%"]:
            flash("Ungültige Eingabe.", "danger")
        else:
            exists = execute("SELECT 1 FROM codes WHERE code=?", (code,), fetchone=True)
            if exists:
                execute("UPDATE codes SET wert=?, einheit=? WHERE code=?", (wert_f, einheit, code), commit=True)
                flash("Code aktualisiert.", "success")
            else:
                execute("INSERT INTO codes (code, wert, einheit, usage) VALUES (?,?,?,0)", (code, wert_f, einheit), commit=True)
                flash("Code erstellt.", "success")
    if request.args.get("delete"):
        execute("DELETE FROM codes WHERE code=?", (request.args.get("delete"),), commit=True)
        flash("Code gelöscht.", "info")
    rows = execute("SELECT * FROM codes ORDER BY code", fetchall=True)
    return render_template("admin_creatorcodes.html", rows=rows)


@app.route("/admin/users", methods=["GET", "POST"])
@admin_required
def admin_users():
    if request.method == "POST":
        uid = request.form.get("user_id")
        action = request.form.get("action")
        if action == "toggle_admin":
            execute("UPDATE users SET is_admin = CASE WHEN is_admin=1 THEN 0 ELSE 1 END WHERE id=?", (uid,), commit=True)
        elif action == "password":
            pw = request.form.get("new_password", "")
            if validate_password(pw):
                execute("UPDATE users SET password=? WHERE id=?", (hash_pw(pw), uid), commit=True)
            else:
                flash("Passwort erfüllt die Anforderungen nicht.", "warning")
    rows = execute("SELECT * FROM users ORDER BY id", fetchall=True)
    return render_template("admin_users.html", rows=rows)


@app.route("/admin/orders")
@admin_required
def admin_orders():
    rows = execute("SELECT * FROM orders WHERE storniert=0 ORDER BY order_date DESC", fetchall=True)
    return render_template("admin_orders.html", rows=rows)


@app.route("/admin/support")
@admin_required
def admin_support():
    rows = execute(
        """
        SELECT t.*, u.username,
        (SELECT u2.username FROM ticket_messages m2 JOIN users u2 ON u2.id=m2.sende_by WHERE m2.ticket_id=t.ticket_id ORDER BY m2.message_id DESC LIMIT 1) AS last_user,
        (SELECT m3.timestamp FROM ticket_messages m3 WHERE m3.ticket_id=t.ticket_id ORDER BY m3.message_id DESC LIMIT 1) AS last_time
        FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY t.ticket_id DESC
        """,
        fetchall=True,
    )
    return render_template("admin_support.html", rows=rows)


@app.route("/admin/settings", methods=["GET", "POST"])
@admin_required
def admin_settings():
    team_rows = get_teams_rows()

    if request.method == "POST":
        action = request.form.get("action", "save_prices")
        frist = request.form.get("frist", "")

        if action == "save_prices":
            if frist:
                execute("INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES ('frist',?)", (frist,), commit=True)
            for team in team_rows:
                code = team["code"]
                v = request.form.get(f"price_{code}", "")
                try:
                    parsed = float(v)
                    if parsed < 0:
                        raise ValueError("negative")
                    execute(
                        "INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES (?,?)",
                        (code, f"{parsed:.2f}"),
                        commit=True,
                    )
                except ValueError:
                    flash(f"Preis für {code} ungültig. Wert wurde ignoriert.", "warning")
            flash("Preis-Settings gespeichert.", "success")

        elif action == "add_team":
            name = request.form.get("team_name", "").strip()
            code = request.form.get("team_code", "").strip().upper()
            base_price = request.form.get("team_price", "89.90").strip()
            front_file = request.files.get("front_image")
            back_file = request.files.get("back_image")

            if not re.fullmatch(r"[A-Z]{2,5}", code):
                flash("Kürzel ungültig (nur 2-5 Großbuchstaben).", "danger")
            elif not re.fullmatch(r"[A-Za-zÄÖÜäöüß\\s\\-]{2,40}", name):
                flash("Teamname ungültig.", "danger")
            else:
                try:
                    price_val = float(base_price)
                    if price_val < 0:
                        raise ValueError("negative")
                except ValueError:
                    flash("Grundpreis ungültig.", "danger")
                    price_val = None

                if price_val is not None:
                    exists = execute("SELECT 1 FROM teams WHERE code=?", (code,), fetchone=True)
                    if exists:
                        flash("Dieses Kürzel existiert bereits.", "warning")
                    else:
                        front_rel = save_team_image(front_file, code, "front") or f"assets/trikots/{code.lower()}-front.png"
                        back_rel = save_team_image(back_file, code, "back") or f"assets/trikots/{code.lower()}-back.png"
                        execute(
                            """
                            INSERT INTO teams (code, name, front_image, back_image, is_active)
                            VALUES (?, ?, ?, ?, 1)
                            """,
                            (code, name, front_rel, back_rel),
                            commit=True,
                        )
                        execute(
                            "INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES (?,?)",
                            (code, f"{price_val:.2f}"),
                            commit=True,
                        )
                        flash(f"Neue Mannschaft {name} ({code}) hinzugefügt.", "success")
        elif action == "update_team_images":
            code = request.form.get("team_code", "").strip().upper()
            if not re.fullmatch(r"[A-Z]{2,5}", code):
                flash("Ungültiges Team-Kürzel für Bild-Update.", "danger")
            else:
                team = execute("SELECT * FROM teams WHERE code=? AND is_active=1", (code,), fetchone=True)
                if not team:
                    flash(f"Mannschaft {code} nicht gefunden.", "danger")
                else:
                    front_file = request.files.get("front_image")
                    back_file = request.files.get("back_image")

                    updated = False
                    if front_file and front_file.filename:
                        front_rel = save_team_image(front_file, code, "front")
                        if front_rel:
                            execute("UPDATE teams SET front_image=? WHERE code=?", (front_rel, code), commit=True)
                            updated = True
                        else:
                            flash(f"Vorderseiten-Bild für {code} hat ungültiges Dateiformat.", "warning")

                    if back_file and back_file.filename:
                        back_rel = save_team_image(back_file, code, "back")
                        if back_rel:
                            execute("UPDATE teams SET back_image=? WHERE code=?", (back_rel, code), commit=True)
                            updated = True
                        else:
                            flash(f"Rückseiten-Bild für {code} hat ungültiges Dateiformat.", "warning")

                    if updated:
                        flash(f"Trikot-Bilder für {code} aktualisiert.", "success")
                    elif (not front_file or not front_file.filename) and (not back_file or not back_file.filename):
                        flash(f"Keine neuen Bilddateien für {code} ausgewählt.", "warning")
        else:
            flash("Unbekannte Aktion.", "warning")

        team_rows = get_teams_rows()
    settings = {r["setting_key"]: r["setting_value"] for r in execute("SELECT * FROM settings", fetchall=True)}
    return render_template("admin_settings.html", settings=settings, team_rows=team_rows)


@app.route("/admin/detailedorder", methods=["GET", "POST"])
@admin_required
def detailedorder():
    oid = request.args.get("orderid")
    if request.method == "POST":
        status = request.form.get("status")
        if status in ["ausstehend", "in Bearbeitung", "abgeschlossen"]:
            execute("UPDATE orders SET bearbeitungsstatus=? WHERE order_id=?", (status, oid), commit=True)
    order = execute(
        "SELECT o.*, u.first_name, u.name, u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE order_id=?",
        (oid,),
        fetchone=True,
    )
    if not order:
        flash("Bestellung nicht gefunden.", "danger")
        return redirect(url_for("admin_orders"))
    cart_ids = [int(x) for x in order["cart_ids"].split(",") if x.strip().isdigit()]
    carts = []
    if cart_ids:
        q = f"SELECT * FROM shopping_cart WHERE shopping_cart_id IN ({','.join('?'*len(cart_ids))})"
        carts = execute(q, tuple(cart_ids), fetchall=True)
    return render_template("detailedorder.html", order=order, carts=carts)


@app.route("/admin/userorders")
@admin_required
def userorders():
    uid = request.args.get("user")
    rows = execute(
        "SELECT order_id, payment_progress, bearbeitungsstatus FROM orders WHERE user_id=? ORDER BY order_date DESC",
        (uid,),
        fetchall=True,
    )
    return render_template("userorders.html", rows=rows, uid=uid)


if __name__ == "__main__":
    init_db()
    app.run(host=APP_HOST, port=APP_PORT, debug=True)
